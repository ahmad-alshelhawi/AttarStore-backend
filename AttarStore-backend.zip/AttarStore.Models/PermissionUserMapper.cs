﻿namespace AttarStore.Models
{
    public class PermissionUserMapper
    {
        public long Id { get; set; }
        public PermissionsMapper Permission { get; set; }

    }
}
