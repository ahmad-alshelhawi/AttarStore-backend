﻿

namespace AttarStore.Models
{
    public class TokenRequest
    {
        public string RefreshToken { get; set; }
    }
}
