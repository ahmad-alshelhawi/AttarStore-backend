﻿namespace AttarStore.Models
{
    public class PermissionsMapper
    {
        public long Id { get; set; }
        public string Name { get; set; }

    }
}
